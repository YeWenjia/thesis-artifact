
# Gradual Merging Types:

## Compilation and execution of the source code
To compile this prototype you need to have installed:

+ SBT 1.5.5 (http://www.scala-sbt.org/)
+ Node +v18.18.0 (https://nodejs.org/)
+ JDK8 (https://www.oracle.com/technetwork/java/javase/downloads/)



We can first proceed to compile the frontend, or skip this and go straight to compile the backend (frontend might pre-compiled in location ''public/javascript/app.js''

### Compiling the frontend
To compile this javascript file, you have to enter the node folder first.
- From the application folder:
  ```sh
  cd node
  ```
- Then we have to install node packages (it may take a while).
  ```sh
  npm i
  ```
- Then once all the packages have been installed, we proceed to build and copy the generated javascript file into the web server. There is a convenient file that does this called ''make''. 
  ```sh
  ./make
  ``` 
  If the file does not have permission to run, then execute the following: 
  ```sh
  chmod +x make
  ```


### Compiling the backend
- From the application folder we start SBT: 
  ```sh
  sbt
  ```
- Then we compile the application as follows (it may take a while the first time):
  ```sh
  compile
  ```

### Running the application
- From the application folder we start SBT (unless you already started it): 
  ```sh
  sbt
  ```
- Then we start the web application as follows:
  ```sh
  run
  ```
  This should start a server in the port 9000. To open the prototype, go to http://localhost:9000/gmt/

- In case the port 9000 is already taken, run:
  ```sh
  run <available-port-number>
  ```


### Distributing the application 
- From the application folder we start SBT (unless you already started it): 
  ```sh
  sbt
  ```
- Then to generate a zip file with all the binaries we execute:
  ```sh
  dist
  ```
  ''SBT'' will generate the zip file located at ''target/universal/gmt-0.9.zip''


## Local execution of the binaries

To run the prototype locally, all you need is Java 1.8. Also, check that you have Java 1.8 in the path.

The following instructions are Unix valid commands. If you have Windows installed in your machine, you need to perform the corresponding commands.
- Unzip the file.
  ```sh
  unzip gmt-0.9.zip
  ```
- Go to the "gmt " folder:
  ```sh
  cd gmt-0.9
  ```
- Add run permissions to the binary file:
  ```sh
  chmod +x bin/gmt
  ```
- And then run:
  ```sh
  ./bin/gmt
  ```
  This should start a server in the port 9000. To open the prototype, go to http://localhost:9000/gmt/
- In case the port 9000 is already taken, run:
  ```sh
  ./bin/gmt -Dhttp.port=<available-port-number>
  ```
